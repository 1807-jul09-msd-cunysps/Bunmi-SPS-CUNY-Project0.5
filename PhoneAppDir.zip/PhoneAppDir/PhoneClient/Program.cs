﻿using System;
using System.Collections;// Non Generics
using System.Collections.Generic;// generics
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Xml.Serialization;
using Newtonsoft.Json; // library to serialize and deserialize
using System.Net.Http.Headers;
using PhoneContactLibrary;
using PhoneLibrary;

namespace PhoneContactClient

{ 
    class Programs
    {
        static void Main(string[] args)
        {
            #region
            UserInterface users = new UserInterface();
            users.ViewContacts();
            #endregion
        }
    }
}
