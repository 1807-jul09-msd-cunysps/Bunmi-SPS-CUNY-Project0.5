﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;


namespace SQLConnectionDAL
{

    public c
using System.Threading.Tasks;
using NLog;
lass ConnectToSQL
    {
        string conStr = "Data Source=rev-cuny-b-server.database.windows.net;Initial Catalog=PhoneDirApp;Persist Security Info=True;User ID=bunmialo;Password=Olamide1";

        public List<> GET()
        {

            //SqlConnection conPerson = null;

        }
        public void POST()
        {
           
            //SqlConnection conPerson = null;

        }
    }
}
