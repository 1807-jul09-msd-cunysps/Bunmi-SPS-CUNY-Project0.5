﻿namespace PhoneContactLibrary
{
    public enum Country
    {
        NIG = 234, SEN = 221, GHA = 233, MLI = 233, US = 1, UK = 44, India = 91
    }
}