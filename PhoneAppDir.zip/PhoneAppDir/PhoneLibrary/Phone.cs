﻿namespace PhoneContactLibrary
{
    //public class Phone
    //{
    //    public long Pid { get; set; }
    //    public Country countryCode { get; set; }
    //    public string areaCode { get; set; }
    //    public string number { get; set; }
    //}
}