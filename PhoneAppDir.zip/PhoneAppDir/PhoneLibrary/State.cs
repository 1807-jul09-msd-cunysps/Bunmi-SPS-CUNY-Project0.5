﻿namespace PhoneContactLibrary
{
    public enum State
    {
        AL, AK, CT, CO, DE, GA, IL, IN, HI, MA, NY, NJ, NM, TN, TX, UT, VT, WA, PA, OR
    }
}