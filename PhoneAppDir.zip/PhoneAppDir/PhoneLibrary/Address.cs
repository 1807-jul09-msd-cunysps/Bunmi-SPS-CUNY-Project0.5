﻿using System.Collections.Generic;
namespace PhoneContactLibrary
{
    public class Address
    {
        //public long Pid { get; set; }
        //public string houseNo { get; set; }
        //public string streetName { get; set; }
        //public string city { get; set; }
        //public State state { get; set; }
        //public string zipCode { get; set; }
        //public Country Country { get; set; }
        //public override string ToString()
        //{
        //    return "Id: " + Pid + "\nHouse No: " + houseNo + "\nStreet Name: " + streetName + "\ncity: " + city + "\nstate: " + state + "\nZip code: " + zipCode + "\nCountry: " + Country;
        //}

    }

}